import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Short here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Short extends GrassGround
{
    /**
     * Act - do whatever the Short wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        bulletHits();
    }
    
    public void bulletHits(){
        Actor bullet = getOneIntersectingObject(Bullet.class);
        if(bullet != null){
            getWorld().removeObject(bullet);
        }

    }
}