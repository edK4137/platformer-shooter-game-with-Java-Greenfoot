import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Snake here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */



public class Snake extends Actor
{
    /**
     * Act - do whatever the Snake wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    int xSpeed = -4;
    int ySpeed = -1;
    int count = 0;
    int health = 3;
    boolean hittedByBullet = false;
    
    public Snake(){
        getImage().mirrorHorizontally();
    }
    
    public void act()
    {
        count += 1;
        moveAround();
        hitByBullet();
        // Add your action code here.
    }
    
    public void moveAround(){
        if(count < 60){
          setLocation(getX() + xSpeed, getY() + ySpeed);  
          if(count %10 == 0){
              ySpeed = -ySpeed;
          }
        }
        else{
            xSpeed = -xSpeed;
            getImage().mirrorHorizontally();
            count = 0;
        }
           
        
    }
    
    public void hitByBullet(){
        Actor bullet = getOneIntersectingObject(Bullet.class);
        if(bullet != null && !hittedByBullet){
            health -= Human.damage;
            hittedByBullet = true;
            getWorld().removeObject(bullet);
        } else if(!isTouching(Bullet.class)) {
            hittedByBullet = false;
        }
        if(health <= 0){
            getWorld().removeObject(this);
            ScoreBoard.increaseScore(1);
        }
        
    }
}

















