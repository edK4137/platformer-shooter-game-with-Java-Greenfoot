import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Wide here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Wide extends GrassGround
{
    /**
     * Act - do whatever the Wide wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
