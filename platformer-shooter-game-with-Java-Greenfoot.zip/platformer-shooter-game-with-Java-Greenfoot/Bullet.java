import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    int speed = 21;
    int damage = 1;
    
    public Bullet(){
        getImage().scale(30, 30);
    }
    
    
    
    public int getDamage(){
        return damage;
    }
    
    public void act()
    {
        // Add your action code here.
        turnToMouse();
        move(speed);
       
    }
    
    public void turnToMouse(){
        //turnTowards(Greenfoot.getMouseInfo().getX(), Greenfoot.getMouseInfo().getY());
        
        
        
        
    }
}
