import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ScoreBoard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ScoreBoard extends Actor
{
    /**
     * Act - do whatever the ScoreBoard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private static int score;
    public ScoreBoard(int score){
        this.score = score;
        getImage().clear();
    }
    
    public void act()
    {
        getImage().scale(35, 35);
        scoreBoard();
    }
    
    public void drawScoreBoard(){
        GreenfootImage image = getImage();
        image.clear();
        image.drawString("Score: " + score, 51, getY());
    }
    
    public static void increaseScore(int enemyType){
        switch(enemyType){
            case 1:
                score += 125;
                break;
            case 2:
                score += 250;
                break;
            case 3:
                score += 475;
                break;
            default:
                score += 0;
                break;
        }
    }
    
    public int getScore(){
        return this.score;     
    }
    
    public void scoreBoard(){
        getWorld().showText("Score: " + score, getX() + 55, getY());
    }
}
