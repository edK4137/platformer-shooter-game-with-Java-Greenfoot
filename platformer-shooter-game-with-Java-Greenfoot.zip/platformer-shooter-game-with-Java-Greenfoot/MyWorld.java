import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1600, 900, 1, false); 
        getBackground().setColor(new Color(133, 207, 230));
        getBackground().fill();
        addObject(new Wide(), 369, 867);
        addObject(new Wide(), 1232, 867);
        addObject(new Human(), 50, 810);
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Wide wide = new Wide();
        addObject(wide,1259,245);
        removeObject(wide);
        Short short1 = new Short();
        addObject(short1,620,588);
        Short short2 = new Short();
        addObject(short2,957,411);
        Snake snake = new Snake();
        addObject(snake,1545,800);
        Snake snake2 = new Snake();
        addObject(snake2,1074,345);
        Snake snake3 = new Snake();
        addObject(snake3,735,525);
        Snake snake4 = new Snake();
        addObject(snake4,704,799);
        Snake snake5 = new Snake();
        addObject(snake5,428,806);
        Short short3 = new Short();
        addObject(short3,1357,327);
        Short short4 = new Short();
        addObject(short4,616,236);
        Short short5 = new Short();
        addObject(short5,243,416);
        Snake snake6 = new Snake();
        addObject(snake6,1476,262);
        snake6.setLocation(1471,270);
        Snake snake7 = new Snake();
        addObject(snake7,737,168);
        snake7.setLocation(729,174);
        Snake snake8 = new Snake();
        addObject(snake8,358,348);
        ScoreBoard scoreBoard = new ScoreBoard(0);
        addObject(scoreBoard,51,101);
        Bug bug = new Bug();
        addObject(bug,1548,67);
        Bug bug2 = new Bug();
        addObject(bug2,1421,561);
        Bug bug3 = new Bug();
        addObject(bug3,486,492);
        Bug bug4 = new Bug();
        addObject(bug4,668,58);
        bug3.setLocation(484,521);
        bug4.setLocation(661,81);
        bug.setLocation(1546,167);
        removeObject(snake);
        Elephant elephant = new Elephant();
        addObject(elephant,1561,810);
        elephant.setLocation(1568,792);
        elephant.setLocation(1562,789);
        elephant.setLocation(1564,785);
    }
}
