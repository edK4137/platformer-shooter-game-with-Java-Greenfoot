import greenfoot.*;
import java.util.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Human here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Human extends Actor
{
    /**
     * Act - do whatever the Human wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    int vSpeed = 0;
    int accel = 0;
    int speed = 5;
    boolean notJumped = true;
    boolean touchingSnake = false;
    boolean touchingBug = false;
    boolean touchingElephant = false;
    Health[] health = new Health[9];
    int healthArraySize = 9;
    boolean fillingHealthArray = true;
    public static int damage = 1;
    boolean upgradeLevel1 = true;
    boolean upgradeLevel2 = true;
    boolean upgradeLevel3 = true;
    
    
    ScoreBoard scoreBoard = new ScoreBoard(0);
    


    public void act(){
        jump();
        checkFalling();
        fall();
        landOnTop();
        moveWithKeys();
        fireBullet();
        getDamaged();
        drawingHealth();
        if(upgradeLevel1){
            upgradeLevel1 = false;
            setBulletLevel(1);
        } else if(scoreBoard.getScore() > 500 && upgradeLevel2){
            upgradeLevel2 = false;
            setBulletLevel(2);
        } else if(scoreBoard.getScore() > 1000 && upgradeLevel3){
            upgradeLevel3 = false;
            setBulletLevel(3);
        }
    }
    
    public void drawingHealth(){
        
        if(fillingHealthArray){
            fillingHealthArray = false;
            for(int i = 0; i < 9; i++){
                health[i] = new Health();
            }
        }
        
        for(int i = 0; i < healthArraySize; i++){
            getWorld().addObject(health[i], 51 + (i * 37), 43);
        }
    }
    
    public void getDamaged(){
        Actor snake = getOneIntersectingObject(Snake.class);
        if(snake != null && touchingSnake){
            healthArraySize-= 1;
            getWorld().removeObject(health[healthArraySize]);
            touchingSnake = false;
        }
        else if(!isTouching(Snake.class)){
            touchingSnake = true;
        }
        
        Actor bug = getOneIntersectingObject(Bug.class);
        if(bug != null && touchingBug){
            healthArraySize-= 2;
            getWorld().removeObject(health[healthArraySize + 1]);
            if(healthArraySize > -1){
            getWorld().removeObject(health[healthArraySize]);
            }
            touchingBug = false;
        }
        else if(!isTouching(Bug.class)){
            touchingBug = true;
        }
        
        Actor elephant = getOneIntersectingObject(Elephant.class);
        if(elephant != null && touchingElephant){
            healthArraySize-= 3;
            getWorld().removeObject(health[healthArraySize + 2]);
            if(healthArraySize > -1){
                getWorld().removeObject(health[healthArraySize + 1]);
                if(healthArraySize > -2){
                    getWorld().removeObject(health[healthArraySize]);
                }
            }
            touchingElephant = false;
        }
        else if(!isTouching(Elephant.class)){
            touchingElephant = true;
        }
        
        if(healthArraySize <= 0){
            getWorld().addObject(new GameOver(), 800, 450);
            getWorld().removeObject(this);
        }
    }

    public void fireBullet(){
        if(Greenfoot.mousePressed(null)){
            Bullet bullet = new Bullet();
            getWorld().addObject(bullet, getX() + 20, getY());
            bullet.turnTowards(Greenfoot.getMouseInfo().getX(), Greenfoot.getMouseInfo().getY());
        }
    }

    public void landOnTop(){
        if(isTouching(GrassGround.class)){
            setLocation(getX(), getY() - 1);
            vSpeed = 0;
        }
    }

    public void fall(){
        setLocation(getX(), getY() + vSpeed);
    }

    public void checkFalling(){
        if(!isTouching(GrassGround.class)){
            vSpeed++;        }
        else{
            vSpeed = 0;
            notJumped = true;
        }
    }

    public void jump(){
        if((Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up")) && notJumped){
            vSpeed = -24;
            notJumped = false;
        }
    }

    public void moveWithKeys(){
        if(Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("D") ||Greenfoot.isKeyDown("d")) {
            setLocation(getX() + speed, getY());
        }
        if(Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("A") || Greenfoot.isKeyDown("a")){
            setLocation(getX() - speed, getY());
        }
    }
    
    public void setBulletLevel(int level){
        switch(level){
            case 1:
                damage = 1;
                break;
            case 2:
                damage = 2;
                break;
            case 3:
                damage = 4;
                break;
            default:
                break;
        }
    }

}
