import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class By here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bug extends Actor
{
    /**
     * Act - do whatever the By wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int xSpeed = -4;
    int ySpeed = -3;
    int count = 0;
    int yCount = 0;
    int health = 2;
    boolean hittedByBullet = false;
    
    public Bug(){
        getImage().mirrorHorizontally();
    }
    
    public void act()
    {
        count += 1;
        yCount += 1;
        flyAround();
        hitByBullet();
        // Add your action code here.
    }
    
    public void flyAround(){
        if(count < 100){
            if(yCount % 15 == 0){
                ySpeed = -ySpeed;
            }
            setLocation(getX() + xSpeed, getY() + ySpeed);  
        }
        else{
            xSpeed = -xSpeed;
            ySpeed = -ySpeed;
            getImage().mirrorHorizontally();
            count = 0;
        }
           
        
    }
    
    public void hitByBullet(){
        Actor bullet = getOneIntersectingObject(Bullet.class);
        if(bullet != null && !hittedByBullet){
            health -= Human.damage;
            hittedByBullet = true;
            getWorld().removeObject(bullet);
        } else if(!isTouching(Bullet.class)) {
            hittedByBullet = false;
        }
        if(health <= 0){
            getWorld().removeObject(this);
            ScoreBoard.increaseScore(2);
        }
        
    }
}
