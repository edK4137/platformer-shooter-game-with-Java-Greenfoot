import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Elephant here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Elephant extends Actor
{
    /**
     * Act - do whatever the Elephant wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int xSpeed = -1;
    int ySpeed = -1;
    int count = 0;
    int health = 23;
    boolean hittedByBullet = false;
    
    public Elephant(){
        getImage().scale(100,100);
        getImage().mirrorHorizontally();
    }
    
    public void act()
    {
        count += 1;
        moveAround();
        hitByBullet();
        // Add your action code here.
    }
    
    public void moveAround(){
        if(count < 350){
          setLocation(getX() + xSpeed, getY());
          if(count % 3 == 0){
              setLocation(getX(), getY() + ySpeed);
          }
          if(count % 15 == 0){
              ySpeed = -ySpeed;
          }
        }
        else{
            xSpeed = -xSpeed;
            getImage().mirrorHorizontally();
            count = 0;
        }
           
        
    }
    
    public void hitByBullet(){
        Actor bullet = getOneIntersectingObject(Bullet.class);
        if(bullet != null && !hittedByBullet){
            health -= Human.damage;
            hittedByBullet = true;
            getWorld().removeObject(bullet);
        } else if(!isTouching(Bullet.class)) {
            hittedByBullet = false;
        }
        if(health <= 0){
            getWorld().removeObject(this);
            ScoreBoard.increaseScore(3);
        }
        
    }
}
